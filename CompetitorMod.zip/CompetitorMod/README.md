#Competitor By Kristof1104	

This is a mod for Game Dev Tycoon, 